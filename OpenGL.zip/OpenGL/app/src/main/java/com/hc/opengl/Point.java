package com.hc.opengl;

/**
 * Package com.hc.opengl
 * Created by HuaChao on 2016/7/28.
 */
public class Point {
    public float x;
    public float y;
    public float z;

    public Point(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;

    }
}
